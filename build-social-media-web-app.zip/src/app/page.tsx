import LoopApp from "@/components/loop-app";
import { viewerId } from "@/lib/auth";
import { parsePlace } from "@/lib/social";
import { snapshot } from "@/lib/social-server";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export default async function HomePage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const q = await searchParams;
  const place = parsePlace(Object.fromEntries(Object.entries(q).filter(([, value]) => typeof value === "string")));
  const data = await snapshot(await viewerId(), place);
  return <LoopApp initial={data} initialPlace={place} />;
}
