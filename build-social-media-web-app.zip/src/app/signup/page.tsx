import type { Metadata } from "next";
import { redirect } from "next/navigation";
import AuthForm from "@/components/auth-form";
import { viewerId } from "@/lib/auth";

export const metadata: Metadata = { title: "Create an account · Loop" };

export default async function SignupPage() {
  if (await viewerId()) redirect("/");
  return <AuthForm signup />;
}
