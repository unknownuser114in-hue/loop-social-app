import { type NextRequest, NextResponse } from "next/server";
import { apiError, AppError, checkOrigin, readJson, viewerId } from "@/lib/auth";
import { activity, chat, createContent, inbox, listReplies, mutate, network, snapshot } from "@/lib/social-server";
import { parsePlace } from "@/lib/social";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
const data = (value: unknown) => NextResponse.json(value, { headers: { "Cache-Control": "private, no-store" } });

export async function GET(request: NextRequest) {
  try {
    const q = request.nextUrl.searchParams;
    const kind = q.get("kind"), id = q.get("id") || "";
    const viewer = await viewerId();
    if (!kind) return data(await snapshot(viewer, parsePlace(Object.fromEntries(q))));
    if (kind === "replies") return data(await listReplies(id));
    if (kind === "network") return data(await network(viewer, id, q.get("mode") || ""));
    if (!viewer) throw new AppError("Sign in to continue.", 401);
    if (kind === "inbox") return data(await inbox(viewer));
    if (kind === "chat") return data(await chat(viewer, id));
    if (kind === "activity") return data(await activity(viewer));
    throw new AppError("Unknown request.");
  } catch (error) {
    return apiError(error);
  }
}

export async function POST(request: NextRequest) {
  try {
    checkOrigin(request);
    const viewer = await viewerId();
    if (!viewer) throw new AppError("Sign in to continue.", 401);
    if (request.headers.get("content-type")?.startsWith("multipart/form-data")) {
      if (Number(request.headers.get("content-length")) > 9 * 1024 * 1024) throw new AppError("Choose a file under 8 MB.", 413);
      let form: FormData;
      try { form = await request.formData(); } catch { throw new AppError("We couldn’t read that upload."); }
      return data(await createContent(viewer, form));
    }
    return data(await mutate(viewer, await readJson(request)));
  } catch (error) {
    return apiError(error);
  }
}
