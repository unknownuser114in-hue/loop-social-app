import { type NextRequest } from "next/server";
import { apiError, AppError, checkOrigin, logoutCookie, readJson, register, signIn } from "@/lib/auth";

export const runtime = "nodejs";

export async function POST(request: NextRequest) {
  try {
    checkOrigin(request);
    const body = await readJson(request);
    if (body.action === "signup") return await register(request, body);
    if (body.action === "login") return await signIn(request, body);
    if (body.action === "logout") return await logoutCookie(request);
    throw new AppError("Unknown account action.");
  } catch (error) {
    return apiError(error);
  }
}
